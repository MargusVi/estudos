//26) Escreva um programa que exiba os números de 1 a 100 na tela em ordem decrescente.

public class Exercicio26 {
    public static void main(String[] args) {
        for(int i = 100; i > 0; i--) {
            System.out.println(i);
        }
    }
}